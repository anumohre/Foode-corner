package com.food.FoodPoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodPointApplicationTests {

	@Test
	void contextLoads() {
	}

}
