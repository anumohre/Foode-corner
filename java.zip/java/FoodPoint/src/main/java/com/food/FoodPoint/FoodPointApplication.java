package com.food.FoodPoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodPointApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodPointApplication.class, args);
	}

}
